//
//  ALIndicatorView.h
//  ALIndicatorView
//
//  Created by Antonio Alessandro Chillura on 28/05/18.
//  Copyright © 2018 Antonio Alessandro Chillura. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for ALIndicatorView.
FOUNDATION_EXPORT double ALIndicatorViewVersionNumber;

//! Project version string for ALIndicatorView.
FOUNDATION_EXPORT const unsigned char ALIndicatorViewVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <ALIndicatorView/PublicHeader.h>


